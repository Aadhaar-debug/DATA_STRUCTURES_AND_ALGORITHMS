### Index

* [C++](#cpp)
* [Python](#python)


### <a id="cpp"></a>C++

* [Programmēšana un C++](http://home.lu.lv/~janiszu/courses/eprg/eprg.all.pdf) - Jānis Zuters (PDF)


### Python

* [Programmēšanas pamati ar valodu Python](http://home.lu.lv/~janiszu/courses/python/python3.pdf) - Jānis Zuters (PDF)
