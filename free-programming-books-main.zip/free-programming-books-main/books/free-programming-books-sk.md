### Index

* [Language Agnostic](#language-agnostic)
    * [Právo](#pravo)
* [Python](#python)
    * [Django](#django)


### Language Agnostic

#### Právo

* [Zodpovednosť na internete](https://knihy.nic.cz) - Zodpovednosť na internete (PDF)


### Python

#### Django

* [Príručka k Django Girls](https://tutorial.djangogirls.org/sk/) (1.11) (HTML) (:construction: *in process*)
