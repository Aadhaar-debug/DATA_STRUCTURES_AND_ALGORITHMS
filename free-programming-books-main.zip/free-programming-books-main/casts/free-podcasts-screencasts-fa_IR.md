### Index

* [Programming News](#programming-news)
* [Technology](#technology)


### Programming News

* [پادکست کافه برنامه نویس](https://anchor.fm/codemy) - CafeCodemy (podcast)


### Technology

* [پارس کلیک](https://anchor.fm/parsclick/) - Amir Azimi (podcast)
* [رادیو گیک](https://soundcloud.com/jadijadi) (podcast)
* [رادیو گیک](https://anchor.fm/radiojadi) - Jadi (podcast)
* [رادیو گیک](https://www.youtube.com/playlist?list=PL-tKrPVkKKE1peHomci9EH7BmafxdXKGn) (videocast)
* [Radio Developer - رادیو دولوپر](https://castbox.fm/channel/id4407294) (podcast)
