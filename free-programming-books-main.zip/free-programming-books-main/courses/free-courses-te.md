### Index

* [C](#c)
* [C++](#cpp)
* [Data Structures](#ds)
* [Flutter](#flutter)
* [Java](#java)
* [Javascript](#javascript)
* [Python](#python)
* [R](#r)


### C

* [C Language Tutorials](https://www.youtube.com/playlist?list=PLC2mgeYbYNm-n8Iz-_3MuNsJFzr0UlGUu) - Telugu Computer World (YouTube)


### <a id="cpp"></a>C++

* [C++ Language Tutorials](https://www.youtube.com/playlist?list=PLC2mgeYbYNm9keJjsA95jKa4EUVLd7mQP) - Telugu Computer World (YouTube)


### <a id="ds"></a>Data Structures

* [Stacks and Queues in Telugu || Data Structures in Telugu](https://www.youtube.com/playlist?list=PLXj4XH7LcRfBJVCGguyIFbyj__hDSSBm9) - Sudhakar Atchala (YouTube)


### Flutter

* [Dart & Flutter Tutorials in Telugu](https://www.youtube.com/playlist?list=PLv_sM9ZH4RUXoDYMCpMwHNHz875lzTRcH) - Kotha Abhishek (Chintu Tutorials)
* [Dart Tutorial for Flutter in Telugu](https://www.youtube.com/watch?v=TvSK-451TcA) - Sai Gopi (Sai Gopi)
* [Flutter Andorid App Beginner Tutorials Telugu](https://www.youtube.com/playlist?list=PLbVPygGblyBwT55MkWTpFeBJdyymx1MIV) - Vamshee (codewithvamshee)


### Java

* [Full Java Tutorials in Telugu - Telugu Web Guru](https://www.youtube.com/playlist?list=PLh6Yk2rpZu2Lyt9-2hhRj37otchec1OJL) - (YouTube)


### Javascript

* [Full Java Script Tutorials in Telugu - Telugu Web Guru](https://www.youtube.com/playlist?list=PLh6Yk2rpZu2KqDjTuU_qHr-tI_CHOkIsN) - telugu web guru (YouTube)


### Python

* [Free Programming Fundamentals Tutorial - programming బిగినర్స్ ప్రోగ్రామింగ్ in telugu తెలుగు python - Udemy](https://www.udemy.com/course/programming-for-kids-in-telugu) - Saarvani R (Udemy)
* [Python in Telugu - Step by Step Tutorials](https://www.youtube.com/playlist?list=PLC2mgeYbYNm-3aTUq98pbmrA3P1_m-aJR) - Telugu Computer World (YouTube)


### R

* [R Programming Language Training Videos In telugu - R ట్రైనింగ్ వీడియోస్ ఇన్ తెలుగు R programming ట్రైనింగ్ వీడియోస్ ఇన్ తెలుగు](https://www.youtube.com/playlist?list=PLXx2-0oYp1LO9H8ciGQaTr6SN80dteTlc) - VLR Training (YouTube)

